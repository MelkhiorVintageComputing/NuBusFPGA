/*
 * QEMU Motorola 680x0 Macintosh Video Card Emulation
 *                 Copyright (c) 2012-2018 Laurent Vivier
 *
 * some parts from QEMU G364 framebuffer Emulator.
 *                 Copyright (c) 2007-2011 Herve Poussineau
 *
 * This work is licensed under the terms of the GNU GPL, version 2 or later.
 * See the COPYING file in the top-level directory.
 *
 */

#ifndef GOBOFB_H
#define GOBOFB_H

#include "exec/memory.h"
#include "hw/irq.h"
#include "ui/console.h"
#include "qemu/timer.h"
#include "qom/object.h"

typedef enum  {
    GOBOFB_DISPLAY_APPLE_13_RGB = 7,
    GOBOFB_DISPLAY_HIRES_RGB = 14,
} GobofbDisplayType;

#define HIRES_HRES 1600
#define HIRES_VRES 900

typedef struct GobofbMode {
    uint8_t type;
    uint8_t depth;
    uint32_t mode;
    uint32_t width;
    uint32_t height;
    uint32_t stride;
    uint32_t offset;
} GobofbMode;

#define GOBOFB_NUM_REGS      8

typedef struct GobofbState {
    MemoryRegion mem_vram;
    MemoryRegion mem_vram_alias;
    MemoryRegion mem_ctrl;
    MemoryRegion mem_ctrl_alias;
    QemuConsole *con;

    uint8_t *vram;
    uint32_t vram_bit_mask;
    uint32_t palette_current;
    uint8_t color_palette[256 * 3];
    uint32_t width, height; /* in pixels */
    uint8_t depth;
    uint8_t type;

    uint32_t regs[GOBOFB_NUM_REGS];
    GobofbMode *mode;

    uint32_t irq_state;
    uint32_t irq_mask;
    QEMUTimer *vbl_timer;
    qemu_irq irq;
} GobofbState;

#define TYPE_GOBOFB "sysbus-gobofb"
OBJECT_DECLARE_SIMPLE_TYPE(GobofbSysBusState, GOBOFB)

struct GobofbSysBusState {
    SysBusDevice busdev;

    GobofbState gobofb;
};

#define TYPE_NUBUS_GOBOFB "nubus-gobofb"
OBJECT_DECLARE_TYPE(GobofbNubusState, GobofbNubusDeviceClass, NUBUS_GOBOFB)

struct GobofbNubusDeviceClass {
    DeviceClass parent_class;

    DeviceRealize parent_realize;
    DeviceUnrealize parent_unrealize;
};


struct GobofbNubusState {
    NubusDevice busdev;

    GobofbState gobofb;
};

#endif
