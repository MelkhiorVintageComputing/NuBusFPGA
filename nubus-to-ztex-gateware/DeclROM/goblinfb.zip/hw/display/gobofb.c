/*
 * QEMU Motorola 680x0 Macintosh Video Card Emulation
 *                 Copyright (c) 2012-2018 Laurent Vivier
 *
 * some parts from QEMU G364 framebuffer Emulator.
 *                 Copyright (c) 2007-2011 Herve Poussineau
 *
 * This work is licensed under the terms of the GNU GPL, version 2 or later.
 * See the COPYING file in the top-level directory.
 *
 */

#include "qemu/osdep.h"
#include "qemu/units.h"
#include "ui/console.h"
#include "ui/pixel_ops.h"
#include "hw/nubus/nubus.h"
#include "hw/display/gobofb.h"
#include "qapi/error.h"
#include "hw/qdev-properties.h"
#include "migration/vmstate.h"
#include "trace.h"

#define VIDEO_BASE 0x00000000
#define GOBOFB_BASE  0x00900000 /* from slot */

#define GOBOFB_PAGE_SIZE 4096
#define GOBOFB_VRAM_SIZE (2 *1024 * 1024)

#define GOBOFB_MODE           0x0
#define GOBOFB_VBL_MASK       0x4
//#define GOBOFB_VBL_DIS        0x8
#define GOBOFB_INTR_CLEAR     0xc
#define GOBOFB_RESET          0x10
#define GOBOFB_LUT_ADDR       0x14
#define GOBOFB_LUT            0x18
#define GOBOFB_DEBUG          0x20

#define GOBOFB_INTR_VBL       0x1

#define GOBOFB_INTR_VBL_PERIOD_NS 16625800

#if 1
static GobofbMode gobofb_mode_table[] = {
    { GOBOFB_DISPLAY_HIRES_RGB, 1, 0x2, HIRES_HRES, HIRES_VRES, HIRES_HRES, 0x0 },
    { GOBOFB_DISPLAY_HIRES_RGB, 2, 0x4, HIRES_HRES, HIRES_VRES, HIRES_HRES, 0x0 },
    { GOBOFB_DISPLAY_HIRES_RGB, 4, 0x8, HIRES_HRES, HIRES_VRES, HIRES_HRES, 0x0 },
    { GOBOFB_DISPLAY_HIRES_RGB, 8, 0x0, HIRES_HRES, HIRES_VRES, HIRES_HRES, 0x0 },
};
#endif

typedef void gobofb_draw_line_func(GobofbState *s, uint8_t *d, uint32_t addr,
                                  int width);

#if 1
static inline uint8_t gobofb_read_byte(GobofbState *s, uint32_t addr)
{
/* 	fprintf(stderr, "%s: %d: 0x%08x\n", __PRETTY_FUNCTION__, __LINE__, addr); */
    return s->vram[addr & s->vram_bit_mask];
}
#endif

#if 1
/* 1-bit color */
static void gobofb_draw_line1(GobofbState *s, uint8_t *d, uint32_t addr,
                             int width)
{
	fprintf(stderr, "%s: %d\n", __PRETTY_FUNCTION__, __LINE__);
    uint8_t r, g, b;
    int x;

    for (x = 0; x < width; x++) {
        int bit = x & 7;
        int idx = (gobofb_read_byte(s, addr) >> (7 - bit)) & 1;
        r = s->color_palette[idx * 3];
        g = s->color_palette[idx * 3 + 1];
        b = s->color_palette[idx * 3 + 2];
        addr += (bit == 7);

        *(uint32_t *)d = rgb_to_pixel32(r, g, b);
        d += 4;
    }
}

/* 2-bit color */
static void gobofb_draw_line2(GobofbState *s, uint8_t *d, uint32_t addr,
                             int width)
{
	fprintf(stderr, "%s: %d\n", __PRETTY_FUNCTION__, __LINE__);
    uint8_t r, g, b;
    int x;

    for (x = 0; x < width; x++) {
        int bit = (x & 3);
        int idx = (gobofb_read_byte(s, addr) >> ((3 - bit) << 1)) & 3;
        r = s->color_palette[idx * 3];
        g = s->color_palette[idx * 3 + 1];
        b = s->color_palette[idx * 3 + 2];
        addr += (bit == 3);

        *(uint32_t *)d = rgb_to_pixel32(r, g, b);
        d += 4;
    }
}

/* 4-bit color */
static void gobofb_draw_line4(GobofbState *s, uint8_t *d, uint32_t addr,
                             int width)
{
	fprintf(stderr, "%s: %d\n", __PRETTY_FUNCTION__, __LINE__);
    uint8_t r, g, b;
    int x;

    for (x = 0; x < width; x++) {
        int bit = x & 1;
        int idx = (gobofb_read_byte(s, addr) >> ((1 - bit) << 2)) & 15;
        r = s->color_palette[idx * 3];
        g = s->color_palette[idx * 3 + 1];
        b = s->color_palette[idx * 3 + 2];
        addr += (bit == 1);

        *(uint32_t *)d = rgb_to_pixel32(r, g, b);
        d += 4;
    }
}

/* 8-bit color */
static void gobofb_draw_line8(GobofbState *s, uint8_t *d, uint32_t addr,
                             int width)
{
/* 	fprintf(stderr, "%s: %d\n", __PRETTY_FUNCTION__, __LINE__); */
    uint8_t r, g, b;
    int x;

    for (x = 0; x < width; x++) {
        r = s->color_palette[gobofb_read_byte(s, addr) * 3];
        g = s->color_palette[gobofb_read_byte(s, addr) * 3 + 1];
        b = s->color_palette[gobofb_read_byte(s, addr) * 3 + 2];
        addr++;

        *(uint32_t *)d = rgb_to_pixel32(r, g, b);
        d += 4;
    }
}

/* 16-bit color */
static void gobofb_draw_line16(GobofbState *s, uint8_t *d, uint32_t addr,
                              int width)
{
	fprintf(stderr, "%s: %d\n", __PRETTY_FUNCTION__, __LINE__);
    uint8_t r, g, b;
    int x;

    for (x = 0; x < width; x++) {
        uint16_t pixel;
        pixel = (gobofb_read_byte(s, addr) << 8) | gobofb_read_byte(s, addr + 1);
        r = ((pixel >> 10) & 0x1f) << 3;
        g = ((pixel >> 5) & 0x1f) << 3;
        b = (pixel & 0x1f) << 3;
        addr += 2;

        *(uint32_t *)d = rgb_to_pixel32(r, g, b);
        d += 4;
    }
}

/* 24-bit color */
static void gobofb_draw_line24(GobofbState *s, uint8_t *d, uint32_t addr,
                              int width)
{
	fprintf(stderr, "%s: %d\n", __PRETTY_FUNCTION__, __LINE__);
    uint8_t r, g, b;
    int x;

    for (x = 0; x < width; x++) {
        r = gobofb_read_byte(s, addr + 1);
        g = gobofb_read_byte(s, addr + 2);
        b = gobofb_read_byte(s, addr + 3);
        addr += 4;

        *(uint32_t *)d = rgb_to_pixel32(r, g, b);
        d += 4;
    }
}


enum {
    GOBOFB_DRAW_LINE1,
    GOBOFB_DRAW_LINE2,
    GOBOFB_DRAW_LINE4,
    GOBOFB_DRAW_LINE8,
    GOBOFB_DRAW_LINE16,
    GOBOFB_DRAW_LINE24,
    GOBOFB_DRAW_LINE_NB,
};

static gobofb_draw_line_func * const
                              gobofb_draw_line_table[GOBOFB_DRAW_LINE_NB] = {
    gobofb_draw_line1,
    gobofb_draw_line2,
    gobofb_draw_line4,
    gobofb_draw_line8,
    gobofb_draw_line16,
    gobofb_draw_line24,
};

static int gobofb_check_dirty(GobofbState *s, DirtyBitmapSnapshot *snap,
                             ram_addr_t addr, int len)
{
/* 	fprintf(stderr, "%s: %d\n", __PRETTY_FUNCTION__, __LINE__); */
	return memory_region_snapshot_get_dirty(&s->mem_vram, snap, addr, len);
}

static void gobofb_draw_graphic(GobofbState *s)
{
/* 	fprintf(stderr, "%s: %d\n", __PRETTY_FUNCTION__, __LINE__); */
    DisplaySurface *surface = qemu_console_surface(s->con);
    DirtyBitmapSnapshot *snap = NULL;
    ram_addr_t page;
    uint32_t v = 0;
    int y, ymin;
    int gobofb_stride = s->mode->stride;
    gobofb_draw_line_func *gobofb_draw_line;

    switch (s->depth) {
    case 1:
        v = GOBOFB_DRAW_LINE1;
        break;
    case 2:
        v = GOBOFB_DRAW_LINE2;
        break;
    case 4:
        v = GOBOFB_DRAW_LINE4;
        break;
    case 8:
        v = GOBOFB_DRAW_LINE8;
        break;
    case 16:
        v = GOBOFB_DRAW_LINE16;
        break;
    case 24:
        v = GOBOFB_DRAW_LINE24;
        break;
    }

    gobofb_draw_line = gobofb_draw_line_table[v];
    assert(gobofb_draw_line != NULL);

    snap = memory_region_snapshot_and_clear_dirty(&s->mem_vram, 0x0,
                                             memory_region_size(&s->mem_vram),
                                             DIRTY_MEMORY_VGA);

    ymin = -1;
    page = s->mode->offset;
    for (y = 0; y < s->height; y++, page += gobofb_stride) {
        if (gobofb_check_dirty(s, snap, page, gobofb_stride)) {
            uint8_t *data_display;

            data_display = surface_data(surface) + y * surface_stride(surface);
            gobofb_draw_line(s, data_display, page, s->width);

            if (ymin < 0) {
                ymin = y;
            }
        } else {
            if (ymin >= 0) {
                dpy_gfx_update(s->con, 0, ymin, s->width, y - ymin);
                ymin = -1;
            }
        }
    }

    if (ymin >= 0) {
        dpy_gfx_update(s->con, 0, ymin, s->width, y - ymin);
    }

    g_free(snap);
}
#endif

#if 1
static void gobofb_invalidate_display(void *opaque)
{
/* 	fprintf(stderr, "%s: %d\n", __PRETTY_FUNCTION__, __LINE__); */
    GobofbState *s = opaque;

    memory_region_set_dirty(&s->mem_vram, 0, GOBOFB_VRAM_SIZE);
}
#endif
#if 1
static void gobofb_update_mode(GobofbState *s)
{
	fprintf(stderr, "%s: %d\n", __PRETTY_FUNCTION__, __LINE__);
    s->width = s->mode->width;
    s->height = s->mode->height;
    s->depth = s->mode->depth;

    //trace_gobofb_update_mode(s->width, s->height, s->depth);
    gobofb_invalidate_display(s);
}
#endif

#if 1
static void gobofb_mode_write(GobofbState *s)
{
	fprintf(stderr, "%s: %d\n", __PRETTY_FUNCTION__, __LINE__);
    GobofbMode *gobofb_mode;
    int i;

    for (i = 0; i < ARRAY_SIZE(gobofb_mode_table); i++) {
        gobofb_mode = &gobofb_mode_table[i];

        if (s->type != gobofb_mode->type) {
            continue;
        }

        if ((s->regs[GOBOFB_MODE]) == gobofb_mode->mode) {
		s->mode = gobofb_mode;
		gobofb_update_mode(s);
		break;
        }
    }
}
#endif

#if 1
static GobofbMode *gobofb_find_mode(GobofbDisplayType display_type,
                                  uint16_t width, uint16_t height,
                                  uint8_t depth)
{
	fprintf(stderr, "%s: %d\n", __PRETTY_FUNCTION__, __LINE__);
    GobofbMode *gobofb_mode;
    int i;

    for (i = 0; i < ARRAY_SIZE(gobofb_mode_table); i++) {
        gobofb_mode = &gobofb_mode_table[i];

        if (display_type == gobofb_mode->type && width == gobofb_mode->width &&
                height == gobofb_mode->height && depth == gobofb_mode->depth) {
            return gobofb_mode;
        }
    }

    return NULL;
}
#endif

#if 1
static void gobofb_update_display(void *opaque)
{
/* 	fprintf(stderr, "%s: %d\n", __PRETTY_FUNCTION__, __LINE__); */
    GobofbState *s = opaque;
    DisplaySurface *surface = qemu_console_surface(s->con);

    qemu_flush_coalesced_mmio_buffer();

    if (s->width == 0 || s->height == 0) {
        return;
    }

    if (s->width != surface_width(surface) ||
        s->height != surface_height(surface)) {
        qemu_console_resize(s->con, s->width, s->height);
    }

    gobofb_draw_graphic(s);
}
#endif

#if 1
static void gobofb_update_irq(GobofbState *s)
{
/* 	fprintf(stderr, "%s: %d [%d & %d]\n", __PRETTY_FUNCTION__, __LINE__, s->irq_state, s->irq_mask); */
    uint32_t irq_state = s->irq_state & s->irq_mask;

    if (irq_state) {
        qemu_irq_raise(s->irq);
    } else {
        qemu_irq_lower(s->irq);
    }
}
#endif

#if 1
static void gobofb_vbl_timer(void *opaque)
{
/* 	fprintf(stderr, "%s: %d\n", __PRETTY_FUNCTION__, __LINE__); */
    GobofbState *s = opaque;
    int64_t next_vbl;

    s->irq_state |= GOBOFB_INTR_VBL;
    gobofb_update_irq(s);

    /* 60 Hz irq */
    next_vbl = (qemu_clock_get_ns(QEMU_CLOCK_VIRTUAL) +
                GOBOFB_INTR_VBL_PERIOD_NS) /
                GOBOFB_INTR_VBL_PERIOD_NS * GOBOFB_INTR_VBL_PERIOD_NS;
    timer_mod(s->vbl_timer, next_vbl);
}
#endif

static void gobofb_reset(GobofbState *s)
{
	fprintf(stderr, "%s: %d\n", __PRETTY_FUNCTION__, __LINE__);
#if 1
    int i;

    s->palette_current = 0;
    for (i = 0; i < 256; i++) {
/*         s->color_palette[i * 3] = 255 - i; */
/*         s->color_palette[i * 3 + 1] = 255 - i; */
/*         s->color_palette[i * 3 + 2] = 255 - i; */
        s->color_palette[i * 3] = 255 - i;
        s->color_palette[i * 3 + 1] = 255 - i;
        s->color_palette[i * 3 + 2] = 255 - i;
    }
    memset(s->vram, 0, GOBOFB_VRAM_SIZE);
    gobofb_invalidate_display(s);
#endif
}

#if 1
static uint64_t gobofb_ctrl_read(void *opaque,
                                hwaddr addr,
                                unsigned int size)
{
	fprintf(stderr, "%s: %d\n", __PRETTY_FUNCTION__, __LINE__);
    GobofbState *s = opaque;
    uint64_t val = 0;

    switch (addr) {
    case GOBOFB_MODE:
        val = s->regs[addr >> 2];
        break;
    }

    //trace_gobofb_ctrl_read(addr, val, size);
    return val;
}
#endif

#if 1
static void gobofb_ctrl_write(void *opaque,
                             hwaddr addr,
                             uint64_t val,
                             unsigned int size)
{
/* 	fprintf(stderr, "%s: %d 0x%08lx [%lu / 0x%016lx]\n", __PRETTY_FUNCTION__, __LINE__, addr, val, val); */
    GobofbState *s = opaque;
    int64_t next_vbl;

    switch (addr) {      
    case GOBOFB_MODE ... GOBOFB_MODE + 3: 
        if (val != s->regs[addr >> 2]) {   
		s->regs[addr >> 2] = val;
		gobofb_mode_write(s);
        }
        break;
    case GOBOFB_VBL_MASK:
	    s->irq_mask = val;
	    if (s->irq_mask & GOBOFB_INTR_VBL) {
		    next_vbl = (qemu_clock_get_ns(QEMU_CLOCK_VIRTUAL) +
				GOBOFB_INTR_VBL_PERIOD_NS) /
			    GOBOFB_INTR_VBL_PERIOD_NS * GOBOFB_INTR_VBL_PERIOD_NS;
		    timer_mod(s->vbl_timer, next_vbl);
	    } else {
		    timer_del(s->vbl_timer);
	    }
	    break;
    case GOBOFB_INTR_CLEAR:
        s->irq_state &= ~GOBOFB_INTR_VBL;
        gobofb_update_irq(s);
        break;
    case GOBOFB_RESET:
        s->palette_current = 0;
        s->irq_state &= ~GOBOFB_INTR_VBL;
        gobofb_update_irq(s);
        break;
    case GOBOFB_LUT_ADDR:
        s->palette_current = val;
        if (s->palette_current >= sizeof(s->color_palette)) {
            s->palette_current = 0;
        }
/* 	fprintf(stderr, "palette_current (addr) %d\n", (int) s->palette_current); */
        break;
    case GOBOFB_LUT:
/* 	    fprintf(stderr, "setting %d to 0x%02hhx\n", (int) s->palette_current, (unsigned char)val); */
        s->color_palette[s->palette_current++] = val;
        if ((s->palette_current % 3) == 2) {
            gobofb_invalidate_display(s);
        }
        if (s->palette_current >= sizeof(s->color_palette)) {
            s->palette_current = 0;
        }
/* 	fprintf(stderr, "palette_current (clut) %d\n", (int) s->palette_current); */
        break;
    case GOBOFB_DEBUG:
	    fprintf(stderr, "Debug: 0x%08x\n", (unsigned int)val);
	    break;
    }

    //trace_gobofb_ctrl_write(addr, val, size);
}
#endif

#if 1
static const MemoryRegionOps gobofb_ctrl_ops = {
    .read = gobofb_ctrl_read,
    .write = gobofb_ctrl_write,
    .endianness = DEVICE_BIG_ENDIAN,
    .impl.min_access_size = 1,
    .impl.max_access_size = 4,
};
#endif

static int gobofb_post_load(void *opaque, int version_id)
{
	fprintf(stderr, "%s: %d\n", __PRETTY_FUNCTION__, __LINE__);
#if 1
    gobofb_mode_write(opaque);
#endif
    return 0;
}

static const VMStateDescription vmstate_gobofb = {
    .name = "gobofb",
    .version_id = 1,
    .minimum_version_id = 1,
    .minimum_version_id_old = 1,
    .post_load = gobofb_post_load,
    .fields = (VMStateField[]) {
        VMSTATE_UINT8_ARRAY(color_palette, GobofbState, 256 * 3),
        VMSTATE_UINT32(palette_current, GobofbState),
        VMSTATE_UINT32_ARRAY(regs, GobofbState, GOBOFB_NUM_REGS),
        VMSTATE_END_OF_LIST()
    }
};

#if 1
static const GraphicHwOps gobofb_ops = {
    .invalidate = gobofb_invalidate_display,
    .gfx_update = gobofb_update_display,
};
#endif

static void gobofb_common_realize(DeviceState *dev, GobofbState *s, Error **errp)
{
	fprintf(stderr, "%s: %d\n", __PRETTY_FUNCTION__, __LINE__);
#if 1
    DisplaySurface *surface;

    s->mode = gobofb_find_mode(s->type, s->width, s->height, s->depth);
    if (!s->mode) {
        error_setg(errp, "unknown display mode: width %d, height %d, depth %d",
                   s->width, s->height, s->depth);
        return;
    }

    s->con = graphic_console_init(dev, 0, &gobofb_ops, s);
    surface = qemu_console_surface(s->con);

    if (surface_bits_per_pixel(surface) != 32) {
        error_setg(errp, "unknown host depth %d",
                   surface_bits_per_pixel(surface));
        return;
    }

    memory_region_init_io(&s->mem_ctrl, OBJECT(dev), &gobofb_ctrl_ops, s,
                          "gobofb-ctrl", 0x1000);
/*     memory_region_init_alias(&s->mem_ctrl_alias, OBJECT(dev), "gobofb-ctrl-alias", */
/* 			     &s->mem_ctrl, 0, 0x1000); */

    memory_region_init_ram(&s->mem_vram, OBJECT(dev), "gobofb-vram",
                           GOBOFB_VRAM_SIZE, errp);
/*     memory_region_init_alias(&s->mem_vram_alias, OBJECT(dev), "gobofb-vram-alias", */
/* 			     &s->mem_vram, 0, GOBOFB_VRAM_SIZE); */
    s->vram = memory_region_get_ram_ptr(&s->mem_vram);
    s->vram_bit_mask = GOBOFB_VRAM_SIZE - 1;
    memory_region_set_coalescing(&s->mem_vram);

    s->vbl_timer = timer_new_ns(QEMU_CLOCK_VIRTUAL, gobofb_vbl_timer, s);
    gobofb_update_mode(s);
#endif
}

static void gobofb_nubus_set_irq(void *opaque, int n, int level)
{
/* 	fprintf(stderr, "%s: %d\n", __PRETTY_FUNCTION__, __LINE__); */
    GobofbNubusState *s = NUBUS_GOBOFB(opaque);
    NubusDevice *nd = NUBUS_DEVICE(s);

    nubus_set_irq(nd, level);
}

static void gobofb_nubus_realize(DeviceState *dev, Error **errp)
{
	fprintf(stderr, "%s: %d\n", __PRETTY_FUNCTION__, __LINE__);
    NubusDevice *nd = NUBUS_DEVICE(dev);
    GobofbNubusState *s = NUBUS_GOBOFB(dev);
    GobofbNubusDeviceClass *ndc = NUBUS_GOBOFB_GET_CLASS(dev);
    GobofbState *ms = &s->gobofb;

    ndc->parent_realize(dev, errp);
    if (*errp) {
        return;
    }

    gobofb_common_realize(dev, ms, errp);
    if (*errp) {
        return;
    }

    memory_region_add_subregion(&nd->slot_mem, GOBOFB_BASE, &ms->mem_ctrl);
/*     memory_region_add_subregion(&nd->slot_mem, GOBOFB_BASE + (nd->slot << 20), &ms->mem_ctrl_alias); */
    memory_region_add_subregion(&nd->slot_mem, VIDEO_BASE, &ms->mem_vram);
/*     memory_region_add_subregion(&nd->slot_mem, VIDEO_BASE + (nd->slot << 20), &ms->mem_vram_alias); */

    ms->irq = qemu_allocate_irq(gobofb_nubus_set_irq, s, 0);
}

static void gobofb_nubus_unrealize(DeviceState *dev)
{
	fprintf(stderr, "%s: %d\n", __PRETTY_FUNCTION__, __LINE__);
#if 1
    GobofbNubusState *s = NUBUS_GOBOFB(dev);
    GobofbNubusDeviceClass *ndc = NUBUS_GOBOFB_GET_CLASS(dev);
    GobofbState *ms = &s->gobofb;

    ndc->parent_unrealize(dev);

    qemu_free_irq(ms->irq);
#endif
}

static void gobofb_nubus_reset(DeviceState *d)
{
	fprintf(stderr, "%s: %d\n", __PRETTY_FUNCTION__, __LINE__);
    GobofbNubusState *s = NUBUS_GOBOFB(d);
    gobofb_reset(&s->gobofb);
}
static Property gobofb_nubus_properties[] = {
    DEFINE_PROP_UINT32("width", GobofbNubusState, gobofb.width, HIRES_HRES),
    DEFINE_PROP_UINT32("height", GobofbNubusState, gobofb.height, HIRES_VRES),
    DEFINE_PROP_UINT8("depth", GobofbNubusState, gobofb.depth, 8),
    DEFINE_PROP_UINT8("display", GobofbNubusState, gobofb.type,
                      GOBOFB_DISPLAY_HIRES_RGB),
    DEFINE_PROP_END_OF_LIST(),
};

static void gobofb_nubus_class_init(ObjectClass *klass, void *data)
{
	fprintf(stderr, "%s: %d\n", __PRETTY_FUNCTION__, __LINE__);
    DeviceClass *dc = DEVICE_CLASS(klass);
    GobofbNubusDeviceClass *ndc = NUBUS_GOBOFB_CLASS(klass);

    device_class_set_parent_realize(dc, gobofb_nubus_realize,
                                    &ndc->parent_realize);
    device_class_set_parent_unrealize(dc, gobofb_nubus_unrealize,
                                      &ndc->parent_unrealize);
    dc->desc = "Nubus Macintosh Toby framebuffer";
    dc->reset = gobofb_nubus_reset;
    dc->vmsd = &vmstate_gobofb;
    set_bit(DEVICE_CATEGORY_DISPLAY, dc->categories);
    device_class_set_props(dc, gobofb_nubus_properties);
}

static TypeInfo gobofb_nubus_info = {
    .name          = TYPE_NUBUS_GOBOFB,
    .parent        = TYPE_NUBUS_DEVICE,
    .instance_size = sizeof(GobofbNubusState),
    .class_init    = gobofb_nubus_class_init,
    .class_size    = sizeof(GobofbNubusDeviceClass),
};

static void gobofb_register_types(void)
{
	fprintf(stderr, "%s: %d\n", __PRETTY_FUNCTION__, __LINE__);
    type_register_static(&gobofb_nubus_info);
}

type_init(gobofb_register_types)
